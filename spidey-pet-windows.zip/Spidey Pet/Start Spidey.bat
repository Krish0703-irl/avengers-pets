@echo off
rem Lets Spidey out onto your screen. Right-click him and choose "Put away until later" to stop.
rem conhost --headless runs PowerShell with no window at all. Plain -WindowStyle Hidden
rem does not work when Windows Terminal is the default console, as on Windows 11.
start "" conhost.exe --headless powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0spidey.ps1"
if errorlevel 1 start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0spidey.ps1"
exit
