@echo off
rem Lets Spidey out onto your screen. Right-click him and choose "Put away until later" to stop.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0spidey.ps1"
