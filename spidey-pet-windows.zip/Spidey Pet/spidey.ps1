# Spidey Pet for Windows: a little web-slinger who swings, climbs and hangs around your screen.
# Start it with "Start Spidey.bat". Uses only what ships with Windows 10 and 11.

Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace SpideyPet
{
    public class Pose
    {
        public double[] na, fa, nl, fl;
        public Pose(double[] na, double[] fa, double[] nl, double[] fl)
        {
            this.na = na; this.fa = fa; this.nl = nl; this.fl = fl;
        }
    }

    public class Fade
    {
        public double x1, y1, x2, y2, life;
    }

    public class SpideyForm : Form
    {
        static readonly Random Rng = new Random();
        static double Rand(double a, double b) { return a + Rng.NextDouble() * (b - a); }
        static double Clamp(double v, double lo, double hi) { return Math.Max(lo, Math.Min(hi, v)); }
        static double Wrap(double a) { return Math.Atan2(Math.Sin(a), Math.Cos(a)); }
        static string Pick(string[] arr) { return arr[Rng.Next(arr.Length)]; }

        // Everything painted in this color turns see-through. It is a near-black, so the
        // soft edges of the hero's dark outline blend into it without a visible fringe.
        static readonly Color Key = Color.FromArgb(10, 4, 8);
        static readonly Color Red = Color.FromArgb(219, 26, 36);
        static readonly Color RedDk = Color.FromArgb(158, 15, 26);
        static readonly Color Blue = Color.FromArgb(33, 69, 184);
        static readonly Color BlueDk = Color.FromArgb(20, 43, 122);
        static readonly Color Ink = Color.FromArgb(26, 10, 15);

        const double S = 1.6;          // drawing scale: the hero is about 75px tall
        const double G = 1500;         // gravity, px/s^2
        const double LEG = 16;         // leg length in drawing units
        static readonly double StandH = 16.5 * S;

        static readonly string[] Quips = {
            "Thwip!", "Just your friendly neighborhood desktop hero.", "My spider-sense is tingling...",
            "Nice wallpaper!", "Anyone need a web?", "Hanging around, as usual.", "Swinging by!"
        };
        static readonly string[] PatQuips = { "Thwip!", "Hey there!", "Woo-hoo!", "Spider-flip!", "That tickles!" };

        [DllImport("user32.dll")]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);

        double K;        // screen pixels per layout pixel (display scaling)
        double W, H;     // layout size of the area above the taskbar
        string state = "hang";
        double x, y, vx, vy, rot = Math.PI, t, timer, spin, blink = 3;
        int dir = 1, chain;
        double L, Lt, theta, omega, climbTo;
        bool hasAnchor, hasShot, paused;
        double ax, ay, sx, sy, sp;
        List<Fade> fading = new List<Fade>();
        string bubble;
        double bubbleTime;
        double lastQuip, nextQuip = 50, lastTop;
        Stopwatch clock = Stopwatch.StartNew();
        double lastTick;
        RectangleF lastBox = RectangleF.Empty;
        bool pressed, dragging;
        double pressX, pressY, offX, offY;
        List<double[]> moves = new List<double[]>();
        ContextMenuStrip menu;
        ToolStripMenuItem pauseItem;
        Font font = new Font("Segoe UI", 13f, FontStyle.Bold, GraphicsUnit.Pixel);

        public SpideyForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            Text = "Spidey";
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            Bounds = wa;
            BackColor = Key;
            TransparencyKey = Key;
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.UserPaint, true);
            using (Graphics g = CreateGraphics()) K = g.DpiX / 96.0;
            W = wa.Width / K;
            H = wa.Height / K;

            BuildMenu();
            // Enter by dropping down from the top of the screen on a web.
            x = Rand(W * 0.2, W * 0.8);
            y = 0;
            StartHang(0);
            Say("Hey! Your friendly neighborhood desktop hero.", 4);

            System.Windows.Forms.Timer timerCtl = new System.Windows.Forms.Timer();
            timerCtl.Interval = 33;
            timerCtl.Tick += delegate { Tick(); };
            timerCtl.Start();
        }

        // Never take focus away from what you're doing, and stay out of Alt+Tab.
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x80 | 0x08000000; // WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
                return cp;
            }
        }

        double Now() { return clock.Elapsed.TotalSeconds; }
        double Floor { get { return H; } }

        void Say(string text, double secs)
        {
            bubble = text;
            bubbleTime = secs;
        }

        // ---- poses: limb angles are {upper, bend}; 0 points down, +pi/2 points the way he faces ----
        Pose GetPose()
        {
            double sw = Math.Sin(t * 9);
            switch (state)
            {
                case "crawl":
                    return new Pose(new[] { 1.0 + 0.5 * sw, -0.4 }, new[] { 1.0 - 0.5 * sw, -0.4 },
                                    new[] { 1.2 + 0.4 * sw, -1.7 }, new[] { 1.2 - 0.4 * sw, -1.7 });
                case "land":
                    return new Pose(new[] { 0.7, -0.3 }, new[] { -0.7, 0.6 }, new[] { 1.5, -1.9 }, new[] { 0.5, -2.3 });
                case "climb":
                {
                    double c = Math.Sin(t * 7);
                    return new Pose(new[] { 2.5 + 0.35 * c, 0.3 }, new[] { 2.2 - 0.35 * c, 0.4 },
                                    new[] { 1.5 + 0.3 * c, -1.4 }, new[] { 1.2 - 0.3 * c, -1.2 });
                }
                case "swing":
                    return new Pose(new[] { Math.PI, 0 }, new[] { 1.1, 0.9 }, new[] { 0.7, -1.3 }, new[] { 0.25, -0.8 });
                case "fly":
                    return new Pose(new[] { 2.3, 0.2 }, new[] { -1.2, 0.6 }, new[] { 0.5, -1.3 }, new[] { -0.3, -0.6 });
                case "hang":
                {
                    double d = Math.Sin(t * 2) * 0.12;
                    return new Pose(new[] { 2.9 + d, 0.3 }, new[] { 3.4 - d, -0.3 }, new[] { 0.06, 0.0 }, new[] { -0.06, 0.0 });
                }
                case "drag":
                {
                    double f = Math.Sin(t * 14);
                    return new Pose(new[] { 2.6 + 0.5 * f, 0.3 }, new[] { 2.4 - 0.5 * f, 0.3 },
                                    new[] { 0.4 + 0.4 * f, -0.4 }, new[] { -0.3 - 0.4 * f, -0.4 });
                }
                default:
                    return new Pose(new[] { 0.3 + 0.06 * Math.Sin(t * 2), 0.45 }, new[] { -0.3, 0.3 },
                                    new[] { 0.12, 0.0 }, new[] { -0.12, 0.0 });
            }
        }

        static void LimbEnd(double ox, double oy, double[] a, double l1, double l2,
                            out double x1, out double y1, out double x2, out double y2)
        {
            x1 = ox + l1 * Math.Sin(a[0]);
            y1 = oy + l1 * Math.Cos(a[0]);
            x2 = x1 + l2 * Math.Sin(a[0] + a[1]);
            y2 = y1 + l2 * Math.Cos(a[0] + a[1]);
        }

        // Where a point on the hero (in drawing units) lands on screen.
        static void ToWorld(double hx, double hy, double rot, int dir, double lx, double ly, out double wx, out double wy)
        {
            double px = lx * dir * S, py = ly * S;
            wx = hx + px * Math.Cos(rot) - py * Math.Sin(rot);
            wy = hy + px * Math.Sin(rot) + py * Math.Cos(rot);
        }

        void HandPos(Pose p, out double hx, out double hy)
        {
            double x1, y1, x2, y2;
            LimbEnd(0, -11, p.na, 7, 7, out x1, out y1, out x2, out y2);
            ToWorld(x, y, rot, dir, x2, y2, out hx, out hy);
        }

        void FeetPos(Pose p, out double fx, out double fy)
        {
            double a1, b1, a2, b2, c1, d1, c2, d2;
            LimbEnd(0, 0, p.nl, 8, 8, out a1, out b1, out a2, out b2);
            LimbEnd(0, 0, p.fl, 8, 8, out c1, out d1, out c2, out d2);
            ToWorld(x, y, rot, dir, (a2 + c2) / 2, (b2 + d2) / 2, out fx, out fy);
        }

        void BodyCenter(out double cx, out double cy)
        {
            ToWorld(x, y, rot, dir, 0, -9, out cx, out cy);
        }

        // ---- moves ----
        void Decide()
        {
            if (paused)
            {
                state = "idle";
                timer = 3;
                return;
            }
            double r = Rng.NextDouble();
            if (r < 0.3)
            {
                state = "crawl";
                dir = Rng.Next(2) == 0 ? -1 : 1;
                timer = Rand(2, 6);
            }
            else if (r < 0.65)
            {
                Jump(Rng.Next(1, 4), Rand(700, 880));
            }
            else if (r < 0.8)
            {
                StartHang(-1);
            }
            else
            {
                state = "idle";
                timer = Rand(1.5, 4);
                if (Rng.NextDouble() < 0.3) dir = -dir;
            }
        }

        void Jump(int chainCount, double up)
        {
            if (x < 80) dir = 1;
            else if (x > W - 80) dir = -1;
            state = "fly";
            vx = dir * Rand(140, 240);
            vy = -up;
            chain = chainCount;
        }

        bool ShootWeb()
        {
            double ty = Rand(4, 50);
            double dy = y - ty;
            double maxL = Floor - 30 * S - ty;
            if (dy <= 0 || dy >= maxL) return false;
            double room = Math.Sqrt(maxL * maxL - dy * dy);
            double h = Math.Min(Rand(140, 340), room);
            double tx = Clamp(x + dir * h, 20, W - 20);
            if (Math.Abs(tx - x) < 50) return false;
            hasShot = true;
            sx = tx; sy = ty; sp = 0;
            return true;
        }

        void Attach()
        {
            hasShot = false;
            hasAnchor = true;
            ax = sx; ay = sy;
            L = Math.Sqrt((x - ax) * (x - ax) + (y - ay) * (y - ay));
            theta = Math.Atan2(x - ax, y - ay);
            omega = (vx * Math.Cos(theta) - vy * Math.Sin(theta)) / L;
            state = "swing";
            timer = 0;
        }

        void Release()
        {
            double hx, hy;
            HandPos(GetPose(), out hx, out hy);
            fading.Add(new Fade { x1 = ax, y1 = ay, x2 = hx, y2 = hy, life = 0.6 });
            vx = L * omega * Math.Cos(theta);
            vy = -L * omega * Math.Sin(theta) - 150;
            hasAnchor = false;
            state = "fly";
            chain--;
            if (chain <= 0 && Rng.NextDouble() < 0.5) spin = 2 * Math.PI;
        }

        void StartHang(double startL)
        {
            hasAnchor = true;
            hasShot = false;
            ax = x; ay = 0;
            L = startL >= 0 ? startL : Math.Max(0, y);
            Lt = Rand(110, Floor * 0.5);
            theta = 0;
            state = "hang";
            timer = Rand(5, 11);
        }

        void StartClimb(int side)
        {
            dir = side;
            state = "climb";
            vx = vy = 0;
            y = Math.Min(y, Floor - StandH);
            climbTo = Math.Min(Rand(Floor * 0.3, Floor * 0.7), y - 40);
        }

        void Flip()
        {
            Say(Pick(PatQuips), 1.8);
            if (state == "idle" || state == "crawl" || state == "land")
            {
                state = "fly";
                vx = 0;
                vy = -480;
                chain = 0;
                spin = 2 * Math.PI;
            }
        }

        // ---- input ----
        protected override void OnMouseDown(MouseEventArgs e)
        {
            double ex = e.X / K, ey = e.Y / K, cx, cy;
            BodyCenter(out cx, out cy);
            bool onHero = Math.Abs(ex - cx) < 26 * S && Math.Abs(ey - cy) < 26 * S;
            if (e.Button == MouseButtons.Left && onHero)
            {
                pressed = true;
                dragging = false;
                pressX = ex; pressY = ey;
                offX = x - ex; offY = y - ey;
                moves.Clear();
            }
            else if (e.Button == MouseButtons.Right)
            {
                pauseItem.Text = paused ? "Keep moving" : "Stay put";
                menu.Show(Cursor.Position);
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (!pressed) return;
            double ex = e.X / K, ey = e.Y / K;
            if (!dragging && Math.Abs(ex - pressX) + Math.Abs(ey - pressY) > 5)
            {
                dragging = true;
                state = "drag";
                hasAnchor = hasShot = false;
                Say("Whoa, easy!", 1.5);
            }
            if (dragging)
            {
                x = ex + offX;
                y = ey + offY;
                moves.Add(new[] { Now(), x, y });
                if (moves.Count > 5) moves.RemoveAt(0);
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || !pressed) return;
            if (dragging)
            {
                double mvx = 0, mvy = 0;
                if (moves.Count > 1)
                {
                    double[] a = moves[0], b = moves[moves.Count - 1];
                    double dt = Math.Max(b[0] - a[0], 0.01);
                    mvx = (b[1] - a[1]) / dt;
                    mvy = (b[2] - a[2]) / dt;
                }
                vx = Clamp(mvx, -900, 900);
                vy = Clamp(mvy, -900, 900);
                if (Math.Abs(vx) > 30) dir = vx > 0 ? 1 : -1;
                state = "fly";
                chain = 1;
            }
            else
            {
                Flip();
            }
            pressed = false;
            dragging = false;
        }

        void BuildMenu()
        {
            menu = new ContextMenuStrip();
            menu.Items.Add("Swing around", null, delegate
            {
                paused = false;
                if (state == "fly" || state == "swing") chain = 3;
                else Jump(3, Rand(700, 880));
            });
            menu.Items.Add("Hang from the top", null, delegate { StartHang(-1); });
            menu.Items.Add("Climb a wall", null, delegate
            {
                paused = false;
                hasAnchor = hasShot = false;
                dir = x < W / 2 ? -1 : 1;
                state = y >= Floor - StandH - 2 ? "crawl" : "fly";
                timer = 99;
            });
            pauseItem = new ToolStripMenuItem("Stay put", null, delegate
            {
                paused = !paused;
                Say(paused ? "OK, I'll stay here." : "Let's go!", 2);
            });
            menu.Items.Add(pauseItem);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Put away until later", null, delegate { Close(); });
        }

        // ---- loop ----
        void Tick()
        {
            double now = Now();
            double dt = Math.Min(now - lastTick, 0.05);
            lastTick = now;
            Step(dt);
            // Other always-on-top windows can push us down; climb back up now and then.
            if (now - lastTop > 5)
            {
                lastTop = now;
                SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010);
            }
            RectangleF b = Box();
            RectangleF u = lastBox.IsEmpty ? b : RectangleF.Union(b, lastBox);
            lastBox = b;
            Invalidate(new Rectangle((int)Math.Floor(u.X * K), (int)Math.Floor(u.Y * K),
                                     (int)Math.Ceiling(u.Width * K) + 2, (int)Math.Ceiling(u.Height * K) + 2));
        }

        void Step(double dt)
        {
            t += dt;
            blink -= dt;
            if (blink < -0.12) blink = Rand(2.5, 6);
            if (bubble != null)
            {
                bubbleTime -= dt;
                if (bubbleTime <= 0) bubble = null;
            }
            foreach (Fade f in fading) f.life -= dt;
            fading.RemoveAll(delegate (Fade f) { return f.life <= 0; });
            if (!paused && Now() - lastQuip > nextQuip)
            {
                lastQuip = Now();
                nextQuip = Rand(40, 70);
                if (bubble == null) Say(Pick(Quips), 3.5);
            }

            double side = 11 * S, target = 0;
            switch (state)
            {
                case "idle":
                    y = Floor - StandH;
                    timer -= dt;
                    if (timer <= 0) Decide();
                    break;

                case "crawl":
                    y = Floor - 9 * S;
                    x += dir * 95 * dt;
                    target = 0.6 * dir;
                    if (x < side + 4 || x > W - side - 4)
                    {
                        x = Clamp(x, side, W - side);
                        StartClimb(x < W / 2 ? -1 : 1);
                        break;
                    }
                    timer -= dt;
                    if (timer <= 0) Decide();
                    break;

                case "land":
                    y = Floor - 9 * S;
                    target = 0.3 * dir;
                    timer -= dt;
                    if (timer <= 0) Decide();
                    break;

                case "climb":
                    x = dir < 0 ? side : W - side;
                    y -= 150 * dt;
                    if (y <= climbTo)
                    {
                        dir = -dir;
                        Jump(Rng.Next(1, 4), 250);
                        vx = dir * 260;
                    }
                    break;

                case "fly":
                    vy += G * dt;
                    x += vx * dt;
                    y += vy * dt;
                    target = Clamp(vx * 0.0012, -0.5, 0.5);
                    if (hasShot)
                    {
                        sp += dt / 0.12;
                        if (sp >= 1) Attach();
                    }
                    else if (chain > 0 && vy > -80 && y < Floor - 150)
                    {
                        if (!ShootWeb()) chain = 0;
                    }
                    if (state != "fly") break;
                    if (y < 20)
                    {
                        y = 20;
                        vy = Math.Abs(vy) * 0.2;
                    }
                    if (x < side || x > W - side)
                    {
                        x = Clamp(x, side, W - side);
                        hasShot = false;
                        spin = 0;
                        StartClimb(x < W / 2 ? -1 : 1);
                        break;
                    }
                    if (y >= Floor - 9 * S && vy > 0)
                    {
                        y = Floor - 9 * S;
                        vx = vy = 0;
                        spin = 0;
                        hasShot = false;
                        state = "land";
                        timer = 0.45;
                    }
                    break;

                case "swing":
                {
                    omega += (-(G / L) * Math.Sin(theta) + dir * 2.0) * dt;
                    theta += omega * dt;
                    x = ax + L * Math.Sin(theta);
                    y = ay + L * Math.Cos(theta);
                    target = -theta;
                    timer += dt;
                    if (x < side || x > W - side)
                    {
                        Release();
                        x = Clamp(x, side, W - side);
                        StartClimb(x < W / 2 ? -1 : 1);
                    }
                    else if ((dir * omega > 0 && dir * theta > 0.55) || timer > 3.5 || y > Floor - StandH)
                    {
                        Release();
                    }
                    break;
                }

                case "hang":
                {
                    double reel = Lt - L;
                    double rate = (reel < 0 ? 300 : 120) * dt;
                    L += Math.Sign(reel) * Math.Min(Math.Abs(reel), rate);
                    theta = Math.Sin(t * 1.4) * 0.06;
                    x = ax + (L + LEG * S) * Math.Sin(theta);
                    y = ay + (L + LEG * S) * Math.Cos(theta);
                    target = Math.PI - theta;
                    if (Math.Abs(reel) < 2)
                    {
                        timer -= dt;
                        if (!paused && timer <= 0)
                        {
                            if (Rng.NextDouble() < 0.5)
                            {
                                // let go and flip down
                                double fx, fy;
                                FeetPos(GetPose(), out fx, out fy);
                                fading.Add(new Fade { x1 = ax, y1 = ay, x2 = fx, y2 = fy, life = 0.5 });
                                hasAnchor = false;
                                state = "fly";
                                vx = dir * 60;
                                vy = 0;
                                chain = 0;
                            }
                            else
                            {
                                // swing out from the hanging web
                                dir = x < W / 2 ? 1 : -1;
                                L = Math.Sqrt((x - ax) * (x - ax) + (y - ay) * (y - ay));
                                omega = dir * 2.2;
                                state = "swing";
                                chain = Rng.Next(1, 4);
                                timer = 0;
                            }
                        }
                    }
                    break;
                }

                case "drag":
                    target = Math.Sin(t * 6) * 0.25;
                    break;
            }

            if (spin > 0)
            {
                double d = Math.Min(spin, 13 * dt);
                rot += d * dir;
                spin -= d;
            }
            else
            {
                rot += Wrap(target - rot) * Math.Min(1, dt * (state == "swing" ? 14 : 8));
            }
        }

        // The area that needs repainting this frame, in layout pixels.
        RectangleF Box()
        {
            double pad = 34 * S, cx, cy;
            BodyCenter(out cx, out cy);
            double x0 = cx - pad, y0 = cy - pad, x1 = cx + pad, y1 = cy + pad;
            List<double[]> pts = new List<double[]>();
            if (hasAnchor) pts.Add(new[] { ax, ay });
            if (hasShot) pts.Add(new[] { sx, sy });
            foreach (Fade f in fading)
            {
                pts.Add(new[] { f.x1, f.y1 });
                pts.Add(new[] { f.x2, f.y2 });
            }
            if (bubble != null)
            {
                pts.Add(new[] { cx - 140, cy - 34 * S - 80 });
                pts.Add(new[] { cx + 140, cy });
            }
            foreach (double[] p in pts)
            {
                x0 = Math.Min(x0, p[0] - 10);
                y0 = Math.Min(y0, p[1] - 10);
                x1 = Math.Max(x1, p[0] + 10);
                y1 = Math.Max(y1, p[1] + 10);
            }
            return new RectangleF((float)x0, (float)y0, (float)(x1 - x0), (float)(y1 - y0));
        }

        // ---- drawing ----
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            g.ScaleTransform((float)K, (float)K);
            Pose pose = GetPose();
            double hx, hy;
            HandPos(pose, out hx, out hy);

            foreach (Fade f in fading)
                DrawWeb(g, f.x1, f.y1, f.x2, f.y2, f.life / 0.6);
            if (hasShot)
            {
                double p = Math.Min(1, sp);
                DrawWeb(g, hx, hy, hx + (sx - hx) * p, hy + (sy - hy) * p, 1);
            }
            if (hasAnchor)
            {
                // hanging: the web holds his feet once he's flipped over; swinging: his hand
                double ex = hx, ey = hy;
                if (state == "hang" && Math.Cos(rot) < 0) FeetPos(pose, out ex, out ey);
                DrawWeb(g, ax, ay, ex, ey, 1);
                DrawSplat(g, ax, ay);
            }
            DrawHero(g, pose);
            if (bubble != null)
            {
                double cx, cy;
                BodyCenter(out cx, out cy);
                DrawBubble(g, bubble, cx, cy - 34 * S);
            }
        }

        static Pen RoundPen(Color c, double w)
        {
            Pen p = new Pen(c, (float)w);
            p.StartCap = LineCap.Round;
            p.EndCap = LineCap.Round;
            p.LineJoin = LineJoin.Round;
            return p;
        }

        static void Line(Graphics g, Pen p, double x1, double y1, double x2, double y2)
        {
            g.DrawLine(p, (float)x1, (float)y1, (float)x2, (float)y2);
        }

        static void DrawLimb(Graphics g, double ox, double oy, double[] a, double w, Color upper, Color lower, Color tip)
        {
            double len = w > 4.5 ? 8 : 7, x1, y1, x2, y2;
            LimbEnd(ox, oy, a, len, len, out x1, out y1, out x2, out y2);
            using (Pen outline = RoundPen(Ink, w + 1.4))
            {
                g.DrawLines(outline, new[] {
                    new PointF((float)ox, (float)oy), new PointF((float)x1, (float)y1), new PointF((float)x2, (float)y2) });
            }
            using (Pen p = RoundPen(upper, w)) Line(g, p, ox, oy, x1, y1);
            using (Pen p = RoundPen(lower, w)) Line(g, p, x1, y1, x2, y2);
            // gloves and boots
            using (Pen p = RoundPen(tip, w)) Line(g, p, (x1 + x2) / 2, (y1 + y2) / 2, x2, y2);
        }

        void DrawHero(Graphics g, Pose pose)
        {
            GraphicsState saved = g.Save();
            g.TranslateTransform((float)x, (float)y);
            g.RotateTransform((float)(rot * 180 / Math.PI));
            g.ScaleTransform((float)(S * dir), (float)S);

            // far side, in shadow
            DrawLimb(g, 0, -11, pose.fa, 4, RedDk, RedDk, RedDk);
            DrawLimb(g, -0.8, 0, pose.fl, 5, BlueDk, BlueDk, RedDk);

            // torso: blue suit with a red chest and belt
            PointF[] torso = { new PointF(-5.2f, -13.5f), new PointF(5.2f, -13.5f), new PointF(4.2f, 0.5f), new PointF(-4.2f, 0.5f) };
            using (Brush b = new SolidBrush(Blue)) g.FillPolygon(b, torso);
            using (Pen p = RoundPen(Ink, 0.9)) g.DrawPolygon(p, torso);
            PointF[] chest = { new PointF(-4.9f, -13.2f), new PointF(4.9f, -13.2f), new PointF(3.2f, -4f),
                               new PointF(0f, -2.2f), new PointF(-3.2f, -4f) };
            using (Brush b = new SolidBrush(Red))
            {
                g.FillPolygon(b, chest);
                g.FillRectangle(b, -4.25f, -1.6f, 8.5f, 1.8f);
            }
            // chest emblem
            using (Brush b = new SolidBrush(Ink)) g.FillEllipse(b, -0.9f, -9.9f, 1.8f, 1.8f);
            using (Pen p = RoundPen(Ink, 0.5))
            {
                for (int s = -1; s <= 1; s += 2)
                {
                    Line(g, p, 0, -9, 2.2 * s, -10.8);
                    Line(g, p, 0, -9, 2.2 * s, -7.2);
                    Line(g, p, 0, -9, 2.6 * s, -9.4);
                }
            }

            // head with web pattern
            RectangleF head = new RectangleF(-9f, -31f, 18f, 19f);
            using (Brush b = new SolidBrush(Red)) g.FillEllipse(b, head);
            using (GraphicsPath hp = new GraphicsPath())
            {
                hp.AddEllipse(head);
                GraphicsState clipped = g.Save();
                g.SetClip(hp, CombineMode.Intersect);
                using (Pen p = new Pen(Color.FromArgb(140, Ink), 0.35f))
                {
                    for (int k = 0; k < 10; k++)
                    {
                        double a = k * Math.PI / 5;
                        Line(g, p, 0, -20, Math.Cos(a) * 12, -20 + Math.Sin(a) * 12);
                    }
                    g.DrawEllipse(p, -3.5f, -23.5f, 7f, 7f);
                    g.DrawEllipse(p, -6.5f, -26.5f, 13f, 13f);
                }
                g.Restore(clipped);
            }
            using (Pen p = RoundPen(Ink, 0.9)) g.DrawEllipse(p, head);
            // eyes: big white lenses tilted outward
            for (int s = -1; s <= 1; s += 2)
            {
                GraphicsState eye = g.Save();
                g.TranslateTransform((float)(1 + s * 3.6), -22.3f);
                g.RotateTransform((float)(s * 0.55 * 180 / Math.PI));
                float ry = blink < 0 ? 0.5f : 2.2f;
                using (Brush b = new SolidBrush(Color.White)) g.FillEllipse(b, -3.1f, -ry, 6.2f, 2 * ry);
                using (Pen p = RoundPen(Ink, 1)) g.DrawEllipse(p, -3.1f, -ry, 6.2f, 2 * ry);
                g.Restore(eye);
            }

            // near side
            DrawLimb(g, 0.8, 0, pose.nl, 5, Blue, Blue, Red);
            DrawLimb(g, 0, -11, pose.na, 4, Red, Red, Red);
            g.Restore(saved);
        }

        static void DrawWeb(Graphics g, double x1, double y1, double x2, double y2, double alpha)
        {
            alpha = Clamp(alpha, 0, 1);
            using (Pen p = RoundPen(Color.FromArgb((int)(150 * alpha), 64, 69, 82), 3)) Line(g, p, x1, y1, x2, y2);
            using (Pen p = RoundPen(Color.FromArgb((int)(242 * alpha), 255, 255, 255), 1.5)) Line(g, p, x1, y1, x2, y2);
        }

        static void DrawSplat(Graphics g, double x, double y)
        {
            using (Pen p = RoundPen(Color.FromArgb(230, 255, 255, 255), 1.2))
            {
                for (int k = 0; k < 7; k++)
                {
                    double a = k * Math.PI * 2 / 7;
                    Line(g, p, x, y, x + Math.Cos(a) * 7, y + Math.Sin(a) * 7);
                }
                g.DrawEllipse(p, (float)(x - 3.5), (float)(y - 3.5), 7f, 7f);
            }
        }

        void DrawBubble(Graphics g, string msg, double cx, double bottom)
        {
            SizeF size = g.MeasureString(msg, font, 220);
            float bw = size.Width + 20, bh = size.Height + 10, r = 10;
            float bx = (float)Clamp(cx - bw / 2, 4, W - bw - 4);
            float by = (float)Math.Max(4, bottom - bh);
            float tail = (float)Clamp(cx, bx + 14, bx + bw - 14);
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(bx + bw - 2 * r, by, 2 * r, 2 * r, 270, 90);
                path.AddArc(bx + bw - 2 * r, by + bh - 2 * r, 2 * r, 2 * r, 0, 90);
                path.AddLine(tail + 7, by + bh, tail, by + bh + 8);
                path.AddLine(tail, by + bh + 8, tail - 7, by + bh);
                path.AddArc(bx, by + bh - 2 * r, 2 * r, 2 * r, 90, 90);
                path.AddArc(bx, by, 2 * r, 2 * r, 180, 90);
                path.CloseFigure();
                using (Brush b = new SolidBrush(Color.White)) g.FillPath(b, path);
                using (Pen p = RoundPen(Ink, 1.5)) g.DrawPath(p, path);
            }
            using (Brush b = new SolidBrush(Ink))
            using (StringFormat sf = new StringFormat())
            {
                sf.Alignment = StringAlignment.Center;
                g.DrawString(msg, font, b, new RectangleF(bx + 10, by + 5, size.Width, size.Height + 2), sf);
            }
        }
    }

    public static class Program
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        public static void Run()
        {
            bool first;
            using (Mutex one = new Mutex(true, "SpideyPetSingleInstance", out first))
            {
                if (!first) return; // he's already out
                try { SetProcessDPIAware(); } catch { }
                Application.EnableVisualStyles();
                Application.Run(new SpideyForm());
            }
        }
    }
}
'@

[SpideyPet.Program]::Run()
