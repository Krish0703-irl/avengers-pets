SPIDEY PET FOR WINDOWS
A little web-slinger who swings, climbs and hangs around your screen.

Works on: Windows 10 and Windows 11. Nothing extra to install.

START
  1. Unzip this folder (right-click the zip > Extract All).
  2. Double-click "Start Spidey.bat".
     If Windows shows "Windows protected your PC", click "More info" > "Run anyway".
  He drops in from the top of the screen on a web.

PLAY
  Click him       - he does a backflip
  Drag him        - toss him and he webs himself to safety
  Right-click     - swing, hang, climb a wall, stay put, or put him away

He only catches clicks on himself, so the rest of your screen works normally.

START HIM WITH WINDOWS (optional)
  1. Press Windows+R, type  shell:startup  and press Enter.
  2. Right-click "Start Spidey.bat" > Show more options > Create shortcut.
  3. Move that shortcut into the folder that opened.

IF HE DOESN'T SHOW UP
  Double-click "Spidey (show errors).bat". It keeps a window open and shows
  what went wrong.

Fan-made for fun. Spider-Man is a character owned by Marvel.
