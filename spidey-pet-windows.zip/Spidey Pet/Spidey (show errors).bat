@echo off
rem Same as "Start Spidey.bat" but keeps this window open, so you can see any error message.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0spidey.ps1"
echo.
echo Spidey has stopped. If something went wrong, the message is above.
pause
