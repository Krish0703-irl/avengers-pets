#!/bin/sh
# Installs Spidey Pet for the current user and lets him out onto the desktop.
set -e
DIR="$HOME/.local/share/spidey-pet"
mkdir -p "$DIR" "$HOME/.local/share/applications"
cp "$(dirname "$0")/spidey.js" "$DIR/spidey.js"
cat > "$HOME/.local/share/applications/spidey-pet.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Spidey Pet
Comment=A little web-slinger who swings around your screen
Exec=gjs -m $DIR/spidey.js
Icon=face-cool
Terminal=false
Categories=Game;
DESKTOP
if ! command -v gjs >/dev/null 2>&1; then
    echo "Spidey Pet needs gjs. Install it with: sudo apt install gjs"
    exit 1
fi
setsid gjs -m "$DIR/spidey.js" >/dev/null 2>&1 < /dev/null &
echo "Spidey is out! Find him later as 'Spidey Pet' in your app menu."
