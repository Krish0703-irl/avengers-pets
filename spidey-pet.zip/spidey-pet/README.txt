SPIDEY PET
A little web-slinger who swings, climbs and hangs around your screen.

Works on: Linux with the GNOME desktop (for example Ubuntu).

Install:
  1. Unzip this folder.
  2. Open a terminal in it and run:   sh install.sh
  3. Later, open him again from "Spidey Pet" in your app menu.

Play:
  Click him      - he does a backflip
  Drag him       - toss him and he webs himself to safety
  Right-click    - swing, hang, climb a wall, stay put, or put him away

Uninstall:
  rm -r ~/.local/share/spidey-pet ~/.local/share/applications/spidey-pet.desktop

Fan-made for fun. Spider-Man is a character owned by Marvel.
