AVENGERS PETS FOR LINUX
Spider-Man, Iron Man, Captain America, Hulk, Thor, Black Widow, Hawkeye,
Doctor Strange and Mochi living on your screen.

Works on Linux with the GNOME desktop (for example Ubuntu). Needs gjs:
  sudo apt install gjs

INSTALL
  1. Unzip this folder.
  2. Open a terminal in it and run:   sh install.sh
     Add --autostart to start it every time you log in.
  Open "Avengers Pets" from your app menu any time to choose who stays.

PLAY
  Click a hero for a trick, drag to toss them, right-click for their moves.
  Right-click any hero > "Put everyone away" to stop.

UNINSTALL
  sh uninstall.sh

Fan-made for fun. The Marvel characters belong to Marvel.
