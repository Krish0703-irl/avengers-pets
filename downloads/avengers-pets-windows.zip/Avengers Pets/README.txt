AVENGERS PETS FOR WINDOWS
Spider-Man, Iron Man, Captain America, Hulk, Thor, Black Widow, Hawkeye,
Doctor Strange and Mochi living on your screen.

Works on Windows 10 (version 1809 or newer) and Windows 11. Nothing extra to install.

INSTALL
  1. Right-click the zip > Extract All.
  2. Double-click Install.bat.
     If Windows shows "Windows protected your PC", click More info > Run anyway.
  3. Answer whether it should start with Windows. The heroes come out right away.
  Open "Avengers Pets" from the Start menu or desktop any time to choose who stays.

TRY WITHOUT INSTALLING
  Double-click "Start Avengers Pets.bat".

PLAY
  Click a hero for a trick, drag to toss them, right-click for their moves.
  Right-click any hero > "Put everyone away" to stop.

IF THEY DON'T SHOW UP
  Double-click "Avengers Pets (show errors).bat" and read the message it shows.

UNINSTALL
  Double-click Uninstall.bat.

Fan-made for fun. The Marvel characters belong to Marvel.
